"""
"""
import array
import warnings
from psd_tools.utils import fix_byteorder
from psd_tools.constants import Compression, ChannelID, ColorMode, ImageResourceID
try:
    import packbits
    import bpy
except ImportError:
    pass
import collections

class BBox(collections.namedtuple('BBox', 'x1, y1, x2, y2')):
    @property
    def width(self):
        return self.x2-self.x1    
    @property
    def height(self):
        return self.y2-self.y1


def psd_bbox_to_bl(base_height, bbox):
    """ base_height PSD height,
        input bbox in psd,
        return bbox in blender image
    """
    x1 = bbox.x1
    y1 = base_height-bbox.y2
    x2 = bbox.x2 
    y2 = base_height - bbox.y1
    return BBox(x1,y1,x2,y2)

def psd_xy_to_bl(base_height, x1,y1,x2,y2):
    """ base_height PSD height,
        input xy in psd,
        return xy in blender image
    """
    bl_y1 = base_height - y2
    bl_y2 = base_height - y1
    return x1,bl_y1,x2,bl_y2
 

def check_format(header):
    if header.depth not in [8]:
        raise Exception("depth = %d  is unsupport"%header.depth)
    if header.color_mode not in [ColorMode.RGB]:
        raise Exception("color_mode =  %s  is unsupport"% header.color_mode)
    return

def psd_to_bl_image(decoded_data, image = None, image_name = None ):
    if not  image and not  image_name:
        raise  Exception("image and image_name cant be None at same time")
    header = decoded_data.header
    check_format(header)
    layers = decoded_data.layer_and_mask_data.layers  
    pixels = channels_to_bl_pixels(
        channels = decoded_data.image_data,
        channel_ids = _get_psd_channel_ids(header),
        width = header.width,
        height = header.height,        
        depth = header.depth,
        target_has_alpha =  image.use_alpha  if  image else True
    )
    if not image:
        image = bpy.data.images.new(image_name,  header.width, header.height, alpha = True )
    if image_name:
        image.name = image_name 
    image.pixels = pixels
    return image


def group_as_bl(self, image = None):
    return layers_to_bl_image( self.psd.decoded_data, layers_idx, image )


def layer_to_bl_image( decoded_data, layer_idx, image = None):
    header = decoded_data.header
    layers = decoded_data.layer_and_mask_data.layers
    layer = layers.layer_records[layer_idx]
    width = layer.width()
    height = layer.height()

    pixels = channels_to_bl_pixels(
        channels = layers.channel_image_data[layer_idx],
        channel_ids = _get_layer_channel_ids(layer),
        width = width,
        height = height,
        depth = header.depth,
        target_has_alpha = image.use_alpha  if  image else True
    )

    if not image:
        image = bpy.data.images.new(layer.name, width, height, alpha = True )
    image.pixels = pixels
    return image

def combined_bbox(layers, layer_idxs):
    """
    layers : psd layer_records
    layer_idxs: all layers index(only layers)
    """
    lefts = [ layers[layer_idx].left for   layer_idx in layer_idxs]   
    tops = [ layers[layer_idx].top for   layer_idx in layer_idxs]    
    rights = [ layers[layer_idx].right for   layer_idx in layer_idxs]   
    bottoms = [ layers[layer_idx].bottom for   layer_idx in layer_idxs]         
    return BBox(min(lefts), min(tops), max(rights), max(bottoms))

def layers_to_bl_image(decoded_data, layer_idxs, image_name, image = None ):
    if not  image and not  image_name:
        raise  Exception("image and image_name cant be None at same time")
    layers_and_mask =  decoded_data.layer_and_mask_data.layers 
    layers_rd =layers_and_mask.layer_records
    #filter layer
    layer_idxs = [layer_idx for layer_idx in layer_idxs 
                        if  layers_rd[layer_idx].width() > 0 or layers_rd[layer_idx].height() > 0 ]    
    header = decoded_data.header
    depth = header.depth 
    mix_bbox = combined_bbox(layers_rd, layer_idxs)
    mix_size = mix_bbox.width*mix_bbox.height
    mix_pixels = [1.0, 1.0, 1.0, 0.0 ]*mix_size
    for layer_idx in  layer_idxs:
        layer = layers_rd[layer_idx]
        layer_bbox = BBox(layer.left, layer.top, layer.right, layer.bottom)
        if layer.blend_mode !=  b'norm':
            raise Exception("layer %s :%d type = %b unsupport"%(layer.name, layer_idx, layer.blend_mode))  
        layer_datas = channels_decode(depth, layers_and_mask.channel_image_data[layer_idx], layer.width()*layer.height())
        channel_ids = _get_layer_channel_ids(layer)
        layer_pixels = decode_datas_to_bl_pixels(layer_datas, channel_ids, layer.width()*layer.height(), depth, target_has_alpha = True)
        layer_nor_mix(layer_pixels, layer_bbox, mix_pixels, mix_bbox)
    bl_pixels = bl_image_flip_h(mix_pixels, mix_bbox.width, mix_bbox.height, 4)
    if not image:
        image = bpy.data.images.new(image_name, mix_bbox.width, mix_bbox.height, alpha = True )
    if image_name:
        image.name = image_name         
    image.pixels = bl_pixels
    return image


def layer_nor_mix(up_decoded_img, up_bbox, base_decoded_img, base_bbox):
    "base is down layer, and layer_up in  base_decoded_img"
    y_space=up_bbox.y1-base_bbox.y1
    x_space=up_bbox.x1-base_bbox.x1   
    up_w = up_bbox.width
    up_h = up_bbox.height    
    base_w = base_bbox.width
    base_h = base_bbox.height   
    channels_num = 4
    if(up_w ==0):
        return  base_decoded_img
    for up_row in range(up_h):
        for up_col in range(up_w):
            up_idx = (up_row*up_w+up_col)*channels_num
            base_idx = ((up_row+y_space)*base_w+up_col+x_space)*channels_num
            r1,g1,b1,a1 = up_decoded_img[up_idx:up_idx+channels_num]
            r2,g2,b2,a2 = base_decoded_img[base_idx:base_idx+channels_num]             
            base_decoded_img[0+base_idx]  = r1*a1+r2*a2-r2*a1*a2
            base_decoded_img[1+base_idx]  = g1*a1+g2*a2-g2*a1*a2   
            base_decoded_img[2+base_idx]  = b1*a1+b2*a2-b2*a1*a2  
            base_decoded_img[3+base_idx]  = a1+a2-a1*a2           
    return base_decoded_img   


def channels_to_bl_pixels(channels, channel_ids, width, height, depth, target_has_alpha = True):
    if len(channels) == 0:
        raise Exception("channels is empty")    
    px_num = width* height
    bl_channels_num = 4 if target_has_alpha else 3
    bl_pixels = [0] *(px_num*bl_channels_num)
    datas = channels_decode(depth, channels, px_num)
    bl_pixels = decode_datas_to_bl_pixels(datas, channel_ids, width* height, depth, target_has_alpha = True)
    bl_pixels = bl_image_flip_h (bl_pixels, width, height, bl_channels_num)
    return bl_pixels

def array_from_raw(data, depth):
    if depth == 1:
        raise Exception("depth = 1 is unsupport")
    elif depth == 8:
        arr = array.array("B", data)   
    if depth == 16:
        arr = array.array("I", data)
    elif depth == 32:
        arr = array.array("f", data)         
    return fix_byteorder(arr)

def decode_datas_to_bl_pixels(decode_datas, channel_ids, px_size, depth, target_has_alpha = True):
    bl_channels_num = 4 if target_has_alpha else 3
    bl_pixels = [0] *(px_size*bl_channels_num)
    if target_has_alpha: 
        for px_idx in  range(px_size):
            r,g,b,a=get_rgb_px( decode_datas, channel_ids, px_idx)
            idx = px_idx*bl_channels_num        
            bl_pixels[idx:idx+4] = r,g,b,a
    else :
        for px_idx in  range(px_size):
            r,g,b=get_rgb_px( decode_datas, channel_ids, px_idx)
            idx = px_idx*bl_channels_num        
            bl_pixels[idx:idx+3] = r,g,b
    return bl_pixels



def bl_image_flip_h(pixels, width, height, bl_channels_num):
    bl_pixels = pixels.copy()
    line_width = width*bl_channels_num
    len_pixels = height*line_width
    for line in range(height):
        addr = line_width*line
        bl_pixels[len_pixels-addr-line_width : len_pixels-addr] = pixels[addr : addr+line_width]
    return bl_pixels

def channels_decode(depth, channels_data, px_num):
    # psd channels_data to float data
    datas = []
    data = [0.0] * px_num
    float_scale = 2**depth-1
    for idx, channel in enumerate(channels_data):
        channel_data = packbits.decode(channel.data)  if channel.compression == Compression.PACK_BITS else  channel.data
        channel_data = array_from_raw(channel_data, depth).tolist()
        for px_idx, px in enumerate(channel_data):
            data[px_idx] = px/float_scale
        datas.append(data.copy())
    return datas

def get_rgb_px( datas, channel_ids , px_idx):
    for idx, channel_id in enumerate(channel_ids):
        if channel_id == ChannelID.TRANSPARENCY_MASK:
            alpha = datas[idx][px_idx]
        elif  channel_id == ChannelID.RGB_R:
            r = datas[idx][px_idx]
        elif  channel_id == ChannelID.RGB_G:
            g = datas[idx][px_idx]
        elif channel_id == ChannelID.RGB_B:
            b = datas[idx][px_idx]
        else:
            continue
    try:
        return r,g,b,alpha
    except:  
        return r,g,b,1

def _get_psd_channel_ids(header):
    if header.color_mode == ColorMode.RGB:
        if header.number_of_channels == 3:
            return [0, 1, 2]
        elif header.number_of_channels >= 4:
            return [0, 1, 2, ChannelID.TRANSPARENCY_MASK]
    elif header.color_mode == ColorMode.CMYK:
        if header.number_of_channels == 4:
            return [0, 1, 2, 3]
        elif header.number_of_channels == 5:
            # XXX: how to distinguish
            # "4 CMYK + 1 alpha" and "4 CMYK + 1 spot"?
            return [0, 1, 2, 3, ChannelID.TRANSPARENCY_MASK]
    elif header.color_mode == ColorMode.GRAYSCALE:
        if header.number_of_channels == 1:
            return [0]
        elif header.number_of_channels == 2:
            return [0, ChannelID.TRANSPARENCY_MASK]
    else:
        warnings.warn("Unsupported color mode (%s)" % header.color_mode)

def _get_layer_channel_ids(layer):
    return [info.id for info in layer.channels]
